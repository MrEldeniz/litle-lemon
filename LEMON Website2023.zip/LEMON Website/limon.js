function calculateTotal() {
	// Get the form and all its input elements
	var orderForm = document.getElementById("order-form");
	var inputs = orderForm.elements;

	// Initialize total price
	var totalPrice = 0;

	// Loop through all input elements
	for (var i = 0; i < inputs.length; i++) {
		// If the input element is a number input
		if (inputs[i].type == "number") {
			// Get the price of the menu item
			var price = parseFloat(inputs[i].parentElement.previousElementSibling.textContent);
			// Get the quantity of the menu item
			var quantity = parseInt(inputs[i].value);
			// Calculate the price of the menu item
			var itemPrice = price * quantity;
			// Add the price of the menu item to the total price
			totalPrice += itemPrice;
		}
	}

	// Update the total price on the page
	document.getElementById("total-price").textContent = totalPrice.toFixed(2);
}







// carusel0000000000000000000000000000000000000000

function openNav() {
	document.getElementById("myNav").style.display = "block";
  }
  
  function closeNav() {
	document.getElementById("myNav").style.display = "none";
  }
